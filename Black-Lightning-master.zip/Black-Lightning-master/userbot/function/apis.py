# Api(s)
jiobase = "https://www.jiosaavn.com/api.php?__call=autocomplete.get&_format=json&_marker=0&cc=in&includeMetaTags=1&query="
# https://github.com/Cyberboysumanjay/apis
jiocbs = "http://starkmusic.herokuapp.com/result/?query="
torrents = "https://api.sumanjay.cf/torrent/?query="
webshot = "https://api.sumanjay.cf/ss/?url="
covid_global = "https://api.sumanjay.cf/covid/?country="
ekart = "https://api.sumanjay.cf/ekart/"
# https://github.com/Nirmalraj10567/zee5-dl-bot/
token_url1 = "https://useraction.zee5.com/tokennd"
search_api_endpoint = "https://gwapi.zee5.com/content/details/"
platform_token = (
    "https://useraction.zee5.com/token/platform_tokens.php?platform_name=web_app"
)
token_url2 = "https://useraction.zee5.com/token"
stream_baseurl = "https://zee5vodnd.akamaized.net"
