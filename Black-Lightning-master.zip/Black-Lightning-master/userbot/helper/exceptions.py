class CancelProcess(Exception):
    """
    Cancel Process
    """
