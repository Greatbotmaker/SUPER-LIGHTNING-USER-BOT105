#Plugin by @Rishisuperyo
#Animation by kiddo
#kang =gey ,keep credits = cool coder 😶
#usage .146
from telethon import events
import asyncio
from userbot.utils import lightning_cmd
from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"ilu", outgoing=True))
async def hapy(event):
     a="⠀      ｡ﾟﾟ･｡･ﾟﾟ｡\n         ﾟ。        ｡ﾟ\n             ﾟ･｡･ﾟ\n       ︵               ︵ \n    (        ╲       /       /\n      ╲          ╲/       /\n           ╲          ╲  /\n          ╭ ͡   ╲           ╲\n     ╭ ͡   ╲        ╲       ﾉ\n╭ ͡   ╲        ╲         ╱\n ╲       ╲          ╱\n      ╲         ╱\n          ︶ "
     await event.edit(a)
