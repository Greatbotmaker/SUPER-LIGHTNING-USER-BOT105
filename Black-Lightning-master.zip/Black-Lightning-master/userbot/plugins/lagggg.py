# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.



# Copyright BL 2021



from telethon.tl.types import ChannelParticipantsAdmins
# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.



from uniborg.util import lightning_cmd
# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.



@borg.on(lightning_cmd(pattern=r"monster"))
# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.


async def _(event):
# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.


    if event.fwd_from:
        return
# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.


    mentions = " ⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰😈꙰꙰꙰꙰꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰😈꙰꙰꙰꙰꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰😈꙰꙰꙰꙰꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰😈꙰꙰꙰꙰꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰⃟꙰⃟꙰⃟꙰꙰"
# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

   
    chat = await event.get_input_chat()
    async for x in borg.iter_participants(chat, filter=ChannelParticipantsAdmins):
        mentions += f""
    reply_message = None
    # Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

# Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.


    if event.reply_to_msg_id:
        reply_message = await event.get_reply_message()
        await reply_message.reply(mentions)
    else:
        await event.reply(mentions)
    await event.delete()
    # Creator------> @hacker11000
#Userbot-------> Black Lightning Userbot
# Don't kang without permission otherwise put credits....
# if u kang without credit so u r world's biggest noob!.

